#!/usr/bin/python3
import os
from subprocess import Popen, STDOUT
import subprocess
import time
import resource
import sys
import argparse
from progressbar import ProgressBar

#   memory functions 

def memory_limit():
	soft, hard = resource.getrlimit(resource.RLIMIT_AS)
	resource.setrlimit(resource.RLIMIT_AS, (get_memory() * 1024 / 4, hard))

def get_memory():
	with open('/proc/meminfo', 'r') as mem:
		free_memory = 0
		for i in mem:
			sline = i.split()
			if str(sline[0]) in ('MemFree:', 'Buffers:', 'Cached:'):
				free_memory += int(sline[1])
	print(free_memory)
	return free_memory

def group(iterator, count):
	itr = iter(iterator)
	while True:
		try:
			yield tuple([itr.__next__() for i in range(count)])
		except StopIteration:
			print("stop iteration")
			return
		
def divide_chunks(l, n): 
	  
	# looping till length l 
	for i in range(0, len(l), n): 
		yield l[i:i + n] 

def get_alleles(allele_file):
	alleles = [line.rstrip('\n') for line in open(allele_file)]
	return (",".join(alleles))

def create_dir(directory):
    import os, errno

    try:
        os.makedirs(directory)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise 

if __name__ == '__main__':

	parser = argparse.ArgumentParser(description='Get IEDB HLA class II-peptide affinity predictions.')
	parser.add_argument('--main_folder', action = 'store', dest = 'main_folder', default = False, required = True, help = 'The folder where you are working')
	parser.add_argument('--mhc_predictor', action = 'store', dest = 'mhc_predictor', default = False, required = True, help = 'The MHC_II binding predictor Python file from IEDB')
	parser.add_argument('--allele_file', action = 'store', dest = 'allele_file', default = False, required = True, help = 'The file with a list of alleles for IEDB (separated by newline).')
	parser.add_argument('--num_threads', action = 'store', dest = 'num_threads', default = False, required = True, help = 'Number of predictions/processes to be executed simultaneously.')
	parser.add_argument('--sequences_folder', action = 'store', dest = 'sequences_folder', default = False, required = True, help = 'Folder in which protein sequences are stored.')
	parser.add_argument('--output_folder', action = 'store', dest = 'output_folder', default = False, required = True, help = 'Folder in which IEDB output files will be stored.')

	args = parser.parse_args()

#----------------------------

	main_folder = args.main_folder
#	mhc_predictor = args.mhc_predictor
	mhc_pred = args.mhc_predictor
	allele_file = args.allele_file
#	sequences_folder = args.sequences_folder
	seq_folder = args.sequences_folder
	output_folder = args.output_folder
	chunk_size = int(args.num_threads)
	half_chunk = int(chunk_size/2)
	#main_folder = '/data/home/taynafiuza/tmhmmOOH_psortCytoplasmicMembrane_IEDB'
	#mhc_pred = "/data_old/home_old/taynafiuza/mhc_ii/mhc_II_binding.py"
	#alleles = "HLA-DRB1*01:01,HLA-DRB1*03:01,HLA-DRB1*04:01,HLA-DRB1*04:05,HLA-DRB1*07:01,HLA-DRB1*08:02,HLA-DRB1*09:01,HLA-DRB1*11:01,HLA-DRB1*12:01,HLA-DRB1*13:02,HLA-DRB1*15:01,HLA-DRB3*01:01,HLA-DRB3*02:02,HLA-DRB4*01:01,HLA-DRB5*01:01,HLA-DQA1*05:01/DQB1*02:01,HLA-DQA1*05:01/DQB1*03:01,HLA-DQA1*03:01/DQB1*03:02,HLA-DQA1*04:01/DQB1*04:02,HLA-DQA1*01:01/DQB1*05:01,HLA-DQA1*01:02/DQB1*06:02,HLA-DPA1*02:01/DPB1*01:01,HLA-DPA1*01:03/DPB1*02:01,HLA-DPA1*01/DPB1*04:01,HLA-DPA1*03:01/DPB1*04:02,HLA-DPA1*02:01/DPB1*05:01,HLA-DPA1*02:01/DPB1*14:01"
	#seq_folder = '/data/home/taynafiuza/tmhmmOOH_psortCytoplasmicMembrane_IEDB/idx_seq_intersect_tmhmmOOH_psortCytoplasmicMembrane/'
	#output_folder = '/data/home/taynafiuza/tmhmmOOH_psortCytoplasmicMembrane_IEDB/classII_immuno_predictions/'
#	chunk_size = 30	

	os.chdir(main_folder)
	alleles = str(get_alleles(allele_file))
	strain_list = os.listdir(seq_folder+'/')

	#for strain
	p_count = 0
	p_list = []
	pbar = ProgressBar()
	for file in pbar(os.listdir(seq_folder+'/')):
#	for file in os.listdir(seq_folder+'/'):
#		print("***"+file+"***")
		print("")
		print("Analyzing strain "+file)
#		print("")

		sequence_list = os.listdir(seq_folder+'/'+file+'/')

		print("")
		print("Number of proteins: "+str(len(sequence_list)))
		print("")

#		for n_sequences in group(sequence_list, chunk_size):
		#print(sequence_list)
#		print(len(sequence_list))

		for n_sequences in divide_chunks(sequence_list, chunk_size):
			for sequence in n_sequences:
				#print("("+sequence+")", end = ', ')
				#print(sequence)
				#print(output_folder+file)
				create_dir(output_folder+file)
				if os.path.isdir(output_folder+file):
					out = output_folder+file+'/'+sequence+'.consensus3'
#					print(out)
					if not os.path.isfile(out):
						#print('yes')
						with open(output_folder+file+'/'+sequence+'.consensus3',"w") as out:
#							print(sequence)
							p_count = p_count + 1
#							print(type(alleles))
#							exit(0)
							#print("python2.7", mhc_pred, "IEDB_recommended", alleles, seq_folder+'/'+file+'/'+sequence)
							p = subprocess.Popen(["python2.7", mhc_pred, "IEDB_recommended", alleles, seq_folder+'/'+file+'/'+sequence], stdout=out, stderr=True)
							#p = subprocess.Popen(['ls', '-l'], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
							p_list.append(p)
							#print(str(p_count)+" ("+str(sequence)+")", end = '... ')
							print(str(p_count)+" ("+sequence+")", end = '... ')
							time.sleep(2)
						if p_count >= chunk_size:
#							print('\nwait until those '+str(len(p_list))+' processes are finished, please.\n')
							print('\nMaximum number of '+str(len(p_list))+' processes reached. Waiting until half of them are finished.\n')

							for pr in p_list[:half_chunk]:
								pr.wait()
							p_list = p_list[half_chunk:]
							p_count = len(p_list)
		
		print('\nFinishing remaining '+str(len(p_list))+' processes before moving to the next strain.\n')

		for pr in p_list:
			pr.wait()
		p_list = []
		p_count = 0

		print('\nCompressing '+file+' prediction output to save space.\n')
		subprocess.call(['tar', '-cJf', output_folder+file+'.tar.xz', output_folder+file, '--remove-files'])

		print("")
	print("")


