#!/usr/bin/python3

import argparse
import os
import anyat

parser = argparse.ArgumentParser(description='Get proteome from intraspecies name.')
parser.add_argument('--intraspecies_file', action = 'store', dest = 'species_file', default = False, required = True, help = 'The file with the intraspecies name.')
parser.add_argument('--assembly_summary', action = 'store', dest = 'assembly_summary', default = False, required = True, help = 'NCBI most recent assembly summary file')
parser.add_argument('--output_file', action = 'store', dest = 'output_file', default = '../intermediateOutput/species.csv', required = False, help = 'The csv output file name.')
parser.add_argument('--output_folder', action = 'store', dest = 'output_folder', default = '../intermediateOutput/faa_files', required = False, help = 'The csv output folder name.')

args = parser.parse_args()

#------------------

#species_file = '/home/tayna/M_avium/Mah/reAnnotation/speciesFile.tsf'
#assembly_summary = '/home/tayna/M_avium/Mah/reAnnotation/assembly_summary_genbank.txt'

species_file = args.species_file
assembly_summary = args.assembly_summary
output_csv = args.output_file
output_folder = args.output_folder

#get paths to download protein/nucleic acid info
sp_df = anyat.get_paths( species_file, assembly_summary )

#consider only those with complete genomes
sp_df = sp_df.loc[sp_df[2] == 'Complete Genome']

#save this info in a csv file
sp_df.to_csv(output_csv)

#download fna files from all links in sp_df
dir_path = output_folder
anyat.create_dir(output_folder)
sp_df.apply(lambda row: anyat.download_ftp(row[0]+'_'+row[1], row[3], '_protein.faa.gz', output_folder), axis=1)

#decompress files
for file_ in os.listdir(dir_path):
    anyat.decompress(dir_path+'/'+file_)


