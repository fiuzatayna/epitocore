#!/usr/bin/python3
import argparse
import os
import anyat
from progressbar import ProgressBar

parser = argparse.ArgumentParser(description='Predict alpha-helix transmembrane domains.')
parser.add_argument('--faa_folder', action = 'store', dest = 'faa_folder', default = '../intermediateOutput/faa_files/', required = True, help = 'The folder where the .faa files are.')
parser.add_argument('--output_folder', action = 'store', dest = 'output_folder', default = '../intermediateOutput/tmhmm_files/', required = True, help = 'The TMHMM output folder name.')

args = parser.parse_args()

#----------------

print("")
print("")
print("")

faa_folder = args.faa_folder
output_folder = args.output_folder

pbar = ProgressBar()
print("Removing gz files.")
print("")
for file_ in pbar(os.listdir(faa_folder)):
    if file_.endswith(".gz"):
        print(file_)
        os.remove(os.path.join(faa_folder, file_))
print("")

pbar = ProgressBar()
print("Removing duplicates within .faa files.")
print("")
for file_ in pbar(os.listdir(faa_folder)):
    print(file_)
    #anyat.remove_duplicates(os.path.join(faa_folder, file_))
print("")

pbar = ProgressBar()
print("Linearizing .faa files.")
print("")
for file_ in pbar(os.listdir(faa_folder)):
    print(file_)
    anyat.linearize_fasta(os.path.join(faa_folder, file_))    
print("")

anyat.create_dir(output_folder)

print("Predicting alpha transmembrane domains")
print("")    
anyat.execute_tmhmm(faa_folder, output_folder)
print("")    

