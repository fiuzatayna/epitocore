#usage: python filter_onehelix.py [prediction method] [prediction file] 

import sys
import re

def main():
	if sys.argv[1] == 'TMHMM':
		filterTMHMM(sys.argv[2])

	if sys.argv[1] == 'Phobius':
		filterPhobius(sys.argv[2])

#-----------------------------------------------------

def filterTMHMM( output ):
	with open( output ) as tmhmmoutput:
		for line in tmhmmoutput:
			line = line.rstrip()
			
			expectedTMaa=float(line.split()[3].split('=')[1])
			tmCount=int(line.split()[5].split('=')[1].count('-'))

			if expectedTMaa > 18 and tmCount >= 1:
			    print(line)
			#if expectedTMaa > 18 and tmCount == 1:

			    #tmA=int(re.split('[a-zA-Z]', line.split()[5].split('=')[1].split('-')[0])[-1])
			    #tmB=int(re.split('[a-zA-Z]', line.split()[5].split('=')[1].split('-')[0])[-1])

			    #if tmA >= 60 or tmB >= 60:
				    #print(line)

	tmhmmoutput.close()

#-----------------------------------------------------

def filterPhobius( output ):
	with open(output) as phobiusoutput:
		next(phobiusoutput)
		for line in phobiusoutput:

			line = line.rstrip()
			tm=int(line.split()[1])
			sp=line.split()[2]			

			if tm > 1 :
			    print(line)
			if tm == 1 and sp == 'Y':
			    print(line)
			if tm == 1 and sp == '0':
			    tmA=int(re.split('[a-zA-Z]', line.split()[3].split('/')[-1].split('-')[0])[-1])
			    tmB=int(re.split('[a-zA-Z]', line.split()[3].split('/')[-1].split('-')[1])[0])
			    if tmA >= 60 or tmB >= 60:
				    print(line)

	phobiusoutput.close()	 

#-----------------------------------------------------
if __name__ == "__main__":
		main()