#!/usr/bin/python3
#usage: python3 filterTMproteins.py [prediction method] [prediction file] 
#new usage: python3 filterTMproteins.py --prediction_method [prediction method] --prediction_file [prediction file] 

import sys
import re
import argparse
from progressbar import ProgressBar

parser = argparse.ArgumentParser(description='Select proteins with 1 or more alpha-helix transmembrane domains (which span after the 60th aa).')
parser.add_argument('--prediction_method', action = 'store', dest = 'prediction_method', default = 'TMHMM', required = True, help = 'The prediction method used (only TMHMM enabled for now).')
parser.add_argument('--prediction_file', action = 'store', dest = 'prediction_file', required = True, help = 'The TMHMM prediction file.')

args = parser.parse_args()

def main():

	prediction_method = args.prediction_method
	prediction_file = args.prediction_file

	#-----------------------------------------------------

	if prediction_method == 'TMHMM':
		filterTMHMM(prediction_file)

	if prediction_method == 'Phobius':
		filterPhobius(prediction_file)

#-----------------------------------------------------

def filterTMHMM( output ):
	with open( output ) as tmhmmoutput:
		for line in tmhmmoutput:
			line = line.rstrip()
			
			expectedTMaa=float(line.split()[3].split('=')[1])
			tmCount=int(line.split()[5].split('=')[1].count('-'))

			if expectedTMaa > 18 and tmCount >= 2:
			    print(line)
			if expectedTMaa > 18 and tmCount == 1:

			    tmA=int(re.split('[a-zA-Z]', line.split()[5].split('=')[1].split('-')[0])[-1])
			    tmB=int(re.split('[a-zA-Z]', line.split()[5].split('=')[1].split('-')[0])[-1])

			    if tmA >= 60 or tmB >= 60:
				    print(line)

	tmhmmoutput.close()

#-----------------------------------------------------

def filterPhobius( output ):
	with open(output) as phobiusoutput:
		next(phobiusoutput)
		for line in phobiusoutput:

			line = line.rstrip()
			tm=int(line.split()[1])
			sp=line.split()[2]			

			if tm > 1 :
			    print(line)
			if tm == 1 and sp == 'Y':
			    print(line)
			if tm == 1 and sp == '0':
			    tmA=int(re.split('[a-zA-Z]', line.split()[3].split('/')[-1].split('-')[0])[-1])
			    tmB=int(re.split('[a-zA-Z]', line.split()[3].split('/')[-1].split('-')[1])[0])
			    if tmA >= 60 or tmB >= 60:
				    print(line)

	phobiusoutput.close()	 

#-----------------------------------------------------
if __name__ == "__main__":
		main()
