#usage: python3 filter_psort.py psort_out_file cutoff localization_pattern output_file
#example python3 filter_psort.py bacteriaA.psort 7.5 Cellwall bacteriaA_localization_pattern.psort

import pandas as pd
import sys

psort_file = pd.read_csv(sys.argv[1], sep='\t', index_col=False)

psort_file = psort_file[(psort_file.Final_Score >= int(sys.argv[2])) &
                        (psort_file.Final_Localization == sys.argv[3])]

psort_file.to_csv(sys.argv[4], sep='\t', index=False, headers=False)