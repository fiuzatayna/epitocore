#!/usr/bin/python3
#usage python3 get_fasta_from_tmhmm_output.py tmhmm_output_file fasta_file output_file
#example python3 get_fasta_from_tmhmm_output.py bacteriaA bacteriaA.faa bacteriaA_filtered.faa

from Bio import SeqIO
import sys, re
import pandas as pd

tmhmm_file = pd.read_csv(sys.argv[1], sep='\t', index_col=False, header=None)
wanted = tmhmm_file[0].values.tolist()

fasta_sequences = SeqIO.parse(sys.argv[2], 'fasta')

with open(sys.argv[3], "w") as f:
    for seq in fasta_sequences:
        if any([s for s in wanted if seq.id in s]):
            SeqIO.write([seq], f, "fasta")
