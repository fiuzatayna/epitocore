#usage python3 intersect_psort_tmhmm.py tmhmm_outputfile psort_output_file localization output_file
#example python3 intersect_psort_tmhmm.py bacA.tmhmm bacA.psort Unknown bacA.output

import sys
import pandas as pd

tmhmm_file = pd.read_csv(sys.argv[1], sep='\t', index_col=False, header=None)
tmhmm_ids = tmhmm_file[0].tolist()
        
psort_file = pd.read_csv(sys.argv[2], sep='\t', index_col=False)
name = file.split('/')[-1].split('.psort')[0]

psort_pattern = psort_file[(psort_file.Final_Score > 7.5) & (psort_file.Final_Localization == sys.argv[3])]
ids = psort_pattern.SeqID.str.split(' ',expand=True)[0].tolist()
   
intersection = [value for value in ids if value in tmhmm_ids]

output_file = psort_pattern[psort_pattern.SeqID.str.split(' ',expand=True)[0].isin(intersection)]

output_file.to_csv(sys.argv[4], sep='\t', index=False, headers=False)

