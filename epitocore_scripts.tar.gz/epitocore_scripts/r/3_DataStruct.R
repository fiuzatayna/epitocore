#!/usr/bin/Rscript
options( warn = -1 )
source("/scripts/epitocore_df.R")
source('/scripts/configuration_file.R')
suppressMessages(library(dplyr))
suppressMessages(library(stringr))
suppressMessages(library(tidyr))
suppressMessages(library(ggplot2))
suppressMessages(library(optparse))
suppressMessages(library(progress))
suppressMessages(require(svMisc))


#SET working directory
wd <- main_directory
setwd(wd)

#SET clustered classII predictions folder
classIIpath <- paste(wd, 'classII_immuno_predictions_chosen/', sep='/')

#SET tmhmm prediction files with CMGids folder
tmhmmPath <-TMHMM_filtered_output

#SET iedb consensus3 maximum value
threshold_value <- consensus_percentile_rank_filter2

log_file <- file("/home/R_output/3_DataStruct.log", open="a")

#ADD FASTA IDENTIFIER DF
# fasta_ids = read.table(paste(wd, '../filtered_tmhmm_proteins/fasta_ids', sep='/'), header=FALSE, stringsAsFactors = FALSE)
# cmg_ids = read.table(paste(wd, '../filtered_tmhmm_proteins/cmg_ids', sep='/'), header=FALSE, stringsAsFactors = FALSE)

fasta_ids = read.table(fasta_id_list_file, header=FALSE, stringsAsFactors = FALSE)
cmg_ids = read.table(cmg_id_list_file, header=FALSE, stringsAsFactors = FALSE)

trans_ids <- cbind(cmg_ids, fasta_ids)
names(trans_ids) <- c("cmg_id", "fasta_id")

print("    * * * CREATE DATA STRUCT * * * ")
cat("    * * * CREATE DATA STRUCT * * * \n", file=log_file)
df = data.frame()

#for cluster
folderx_size <- length(list.files(classIIpath))
pb <- progress_bar$new(total = folderx_size, format = " [:bar] :percent eta: :eta")
for (folder in list.files(classIIpath)){

  pb$tick()
#  cat("\n")
#  print(paste(" | ", folder, " | "), sep="")
#  print(list.files(classIIpath))
#  print(folder)

  pos <- which(folder == list.files(classIIpath))
  cat(paste(folder, "\n", sep=""), file = log_file)

  #for protein file
  for (file in list.files(paste(classIIpath, folder, sep=""))){
    cat(paste(file, "\n", sep=""), file = log_file)
    
    df_file = paste(classIIpath, file.path(folder, file), sep="")

#    print(df_file)
#    print(file)
#    print(trans_ids[trans_ids$fasta_id == gsub(".consensus3", "", file), "cmg_id"])

    if (file.size(df_file) > 0){
      #read those specific columns
      dfA = read.table(df_file, sep='\t', header=TRUE, stringsAsFactors = FALSE)[c('allele', 'peptide', 'consensus_percentile_rank', 'start', 'end')]
      #select only the rows in which epitopes are among the top 5% highest 
      dfA = dfA[dfA[, "consensus_percentile_rank"] <= threshold_value,]
      
      if (dim(dfA)[1] != 0){
        #add column with cluster info
#        cat("Adding cluster column... ")
        cat("Adding cluster column... ", file = log_file)
        dfA$cluster <- as.numeric(gsub('cluster', '', folder))
#        cat("Adding type column... ")
        cat("Adding type column... ", file = log_file)
        dfA$type <- 'EPITOPE'
#        cat("Adding description column... ")
        cat("Adding description column... ", file = log_file)
        dfA$description <- dfA$peptide
#        cat("Adding order (protein) column... ")
        cat("Adding order (protein) column... ", file = log_file)
        dfA$order <- file
#        dfA$order <- unique(trans_ids[trans_ids$fasta_id == gsub(".consensus3", "", file), "cmg_id"])

#        cat("Adding occurrences column... ")
        cat("Adding occurrences column... ", file = log_file)
        dfA$occurrences <- NA
#        cat("Adding mean_scoring column... ")
        cat("Adding mean_scoring column... ", file = log_file)
        dfA$mean_scoring <- NA
  
#        cat("Adding protein rows... ")
        cat("Adding protein rows... ", file = log_file)
#        paste(classIIpath, folder, sep="")
        dfA <- add_protein_rows(dfA, file, as.numeric(gsub('cluster', '', folder)))
        
#        cat("Adding transmembrane topology column... ")
        cat("Adding transmembrane topology column... ", file = log_file)
        
        dfA <- add_tmtopology_rows(dfA, file, as.numeric(gsub('cluster', '', folder)))
#        cat("Adding epitope list rows... ")
        cat("Adding epitope list rows... ", file = log_file)
        
        dfA <- add_epitopelist_rows(dfA, file, as.numeric(gsub('cluster', '', folder)))
#        cat("Adding outside ratio column... ")
        cat("Adding outside ratio column... ", file = log_file)
        
        dfA <- get_outside_ratio_B(dfA)
 
        cat("Adding order (protein) column... ", file = log_file)
        dfA$order <- unique(trans_ids[trans_ids$fasta_id == gsub(".consensus3", "", file), "cmg_id"])

        df = rbind(dfA, df)
        cat("\n\n\n", file = log_file)
        
      }
    }
  }
}

save(df, file=paste(wd, 'datastruct_allclusters.RData', sep='/'))

dir.create(paste(wd, 'Tables', sep='/'))

#DO INTRA EXTRA PLOT

load(paste(wd, '/datastruct_allclusters.RData', sep='/'))
print("    * * * DO INTRA EXTRA PLOT * * * ")

#INTRA
#gets intracellular epitopes by cluster (counts only once even if peptide repeats accross proteins)
intra_df <- df %>% 
  filter(type == "EPITOPE") %>% 
  distinct(cluster,peptide,outside_ratio) %>% 
  filter(outside_ratio <= 0.5) %>%
  group_by(cluster) %>%
  tally (name="Intracellular")

write.table(intra_df, file=paste(wd, 'Tables/Intracellular_Epitopes_By_Cluster', sep='/'), quote=FALSE, sep='\t', row.names=FALSE)

#EXTRA
#gets extracellular epitopes by cluster (counts only once even if peptide repeats accross proteins)
extra_df <- df %>% 
  filter(type == "EPITOPE") %>% 
  distinct(cluster,peptide,outside_ratio) %>% 
  filter(outside_ratio > 0.5) %>%
  group_by(cluster) %>%
  tally(name="Extracellular")

write.table(extra_df, file=paste(wd, 'Tables/Extracellular_Epitopes_By_Cluster', sep='/'), quote=FALSE, sep='\t', row.names=FALSE)

#merges those counts
intra_extra_df <- merge(intra_df, extra_df, by.x = "cluster", by.y = "cluster", all=TRUE)
write.table(intra_extra_df, file=paste(wd, 'Tables/Intra_x_Extra_Epitopes_By_Cluster', sep='/'), quote=FALSE, sep='\t', row.names=FALSE)

#gather those results in a way that make its easier to plot
intra_extra_gather <- gather(intra_extra_df, intraex, count, Intracellular:Extracellular)

#plots those differences
pdf(paste(wd, 'Figures/Peptide_Position_By_Cluster', sep='/'), width=14, height=6)

ggplot(intra_extra_gather, aes(as.factor(cluster), count, fill=intraex)) + 
geom_bar(stat = "identity", position = 'stack') +
theme(plot.title = element_text(face = "bold", hjust = 0.5)) + 
ggtitle("Peptide Position By Cluster") + xlab("Cluster") + ylab("Count") + 
labs(fill = "Peptide Position") + 
theme_classic() + 
theme(axis.text.x = element_text(color="black", angle = 90, vjust=+0.5, hjust=+0.4), axis.text.y = element_text(color="black"), axis.line.x = element_blank(), axis.ticks.x = element_blank()) + 
scale_y_continuous(expand = c(0,0))  + scale_fill_brewer(palette="Set2")

with_extra <- intra_extra_gather %>% filter(intraex == "Extracellular") %>% filter(!is.na(count)) %>% pull(cluster)

intra_extra_gather %>% 
  filter(cluster %in% with_extra) %>% 
  ggplot(., aes(as.factor(cluster), count, fill=intraex)) + 
  geom_bar(stat = "identity", position = 'stack') +
  theme(plot.title = element_text(face = "bold", hjust = 0.5)) + 
  ggtitle(expression(atop("Peptide Position By Cluster", atop(italic("For clusters with at least one extracellular peptide."), "")))) + xlab("Cluster") + ylab("Count") + 
  labs(fill = "Peptide Position") + 
  theme_classic() + 
  theme(axis.text.x = element_text(color="black", angle = 90, vjust=+0.5, hjust=+0.4), axis.text.y = element_text(color="black"), axis.line.x = element_blank(), axis.ticks.x = element_blank()) + 
  scale_y_continuous(expand = c(0,0))  + scale_fill_brewer(palette="Set2")

dev.off()

#get extracellular protein versus total percentage
extra_percentage <- intra_extra_df %>% replace(., is.na(.), 0) %>% mutate(percentage = (Extracellular / (Extracellular + Intracellular) * 100))
write.table(extra_percentage, file=paste(wd, 'Tables/Extracellular_Epitopes_Percentage_x_All_Epitopes_By_Cluster', sep='/'), quote=FALSE, sep='\t', row.names=FALSE)

print("extracellular percentage summary")
summary(extra_percentage$percentage)
#summary(extra_percentage$percentage[extra_percentage$percentage > 0])

#------- ONLY EXTERNAL NOW

print("    * * * SELECT ONLY CLUSTERS WITH EXTERNAL EPITOPES * * * ")

proteins <- df %>% 
  filter(type == "EPITOPE") %>% 
  filter(consensus_percentile_rank <= threshold_value) %>% 
  filter(outside_ratio > 0.5 | is.na(outside_ratio)) %>%
  distinct(order) %>% 
  pull(order)

df <- df %>% 
  filter(order %in% proteins) %>% 
  filter(consensus_percentile_rank <= threshold_value | is.na(consensus_percentile_rank)) %>% 
  filter(outside_ratio > 0.5 | is.na(outside_ratio))   

#ADD FREQUENCY COLUMN
cat("Adding frequency column... ")
frequency = aggregate(df$order, list(cluster=df$cluster, peptide=df$peptide),  frequency<- function(x) length(unique(x)))
names(frequency)[3] <- "frequency"
df <- merge(df, frequency[ , c("peptide", "frequency")], by.x = "peptide", by.y = "peptide", all.x=TRUE)

#ADD PROMISCUITY COLUMN
cat("Adding promiscuity column... ")
promiscuity = aggregate(df$allele, list(cluster=df$cluster, peptide=df$peptide),  function(x) length(unique(x)))
names(promiscuity)[3] <- "promiscuity"
df <- merge(df, promiscuity[ , c("peptide", "promiscuity")], by.x = "peptide", by.y = "peptide", all.x=TRUE)

#ADD OUTSIDE? COLUMN
cat("Adding outside column... ")
df <- df %>% mutate(outside = ifelse(outside_ratio>0.5,"yes","no"))

df <- merge(df, trans_ids, by.x = "order", by.y = "cmg_id", all.x=TRUE)

save(df, file=paste(wd, 'datastruct.RData', sep='/'))
save(df, file=paste(wd, 'datastruct_external.RData', sep='/'))

#load(paste(wd, 'datastruct.RData', sep='/'))
