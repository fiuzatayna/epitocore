#!/usr/bin/Rscript
options( warn = -1 )
suppressMessages(require(svMisc))
suppressMessages(library(progress))
suppressMessages(library(pbapply))
source("/scripts/epitocore_df.R")
source('/scripts/configuration_file.R')

#PART 1
#get surfaceome output file
surf_output <- last_surfaceome_group_file

#count maximum number of columns
nf <- max(count.fields(surf_output))

#get info to dataframe
surf_df <- read.table(surf_output, sep='\t', header=FALSE, fill = NA, col.names = 1:nf, stringsAsFactors = FALSE)

#consider only first part of protein identifier, which denotes strain 
surf_df_pt <- t(apply(surf_df[c(-1, -2)], 1, function(x) gsub('[[:punct:]][[:digit:]]*', '', x)))
#finds number of unique strains in a row
unique_surf <- apply(surf_df_pt, MARGIN=1, function(x) length(unique(x)[unique(x) != ""]))

#keeps row with n strains
surf_df_u <- surf_df[unique_surf >= 1,]

#get immune output file
cII_output <- '/home/R_output/classII_df.tsv'
#count maximum number of columns
nf <- max(count.fields(cII_output))
#get info to dataframe
cII_df <- read.table(cII_output, sep='\t', header=TRUE, fill = NA, col.names = 1:nf, stringsAsFactors = FALSE)
#remove last column
cII_df <- cII_df[,-1]

#gets rows in immune dataframe where surfaceome dataframe has seven strains
#cII_df_7 = cII_df[unique_surf >= 1,]
cII_df_7 = cII_df[unique_surf >= minimum_strain_occurrence,]

#CHECK THIS LATER
cII_df_7_nona = cII_df_7

#calculates the mean immune score considering all columns but the last two
cII_df_7_nona_mean = rowMeans(cII_df_7_nona[,c(-1,-2)], na.rm=TRUE)
#aggregates this mean column to the immune dataframe removing the last two columns
cII_df_7_nona_mean_df = cbind(cII_df_7_nona, mean=rowMeans(cII_df_7_nona[,c(-1,-2)], na.rm=TRUE))

#consensus_percentile_rank score threshold
threshold_value = consensus_percentile_rank_filter2

#transfers chosen rows based on the mean score
cII_df_chosen = cII_df_7_nona[cII_df_7_nona_mean <= threshold_value,]
cII_df_chosen_II = cII_df_7_nona_mean[cII_df_7_nona_mean <= threshold_value]

#transfers NOT-CHOSEN rows based on the mean score
cII_df_not_chosen = cII_df_7_nona[cII_df_7_nona_mean > threshold_value,]
cII_df_not_chosen_II = cII_df_7_nona_mean[cII_df_7_nona_mean > threshold_value]

#adds the mean column
cII_df_chosen = cbind(cII_df_chosen, mean=cII_df_chosen_II)

#adds mean column to the not chosen df
cII_df_not_chosen = cbind(cII_df_not_chosen, mean=cII_df_not_chosen_II)

#normalizes those scores for plotting
x <- cII_df_7_nona_mean_df$mean
norm_x <- (x - min(x, na.rm = TRUE))/(max(x, na.rm = TRUE)-min(x, na.rm = TRUE))
x <- cII_df_chosen$mean
norm_x_chosen <- (x - min(x, na.rm = TRUE))/(max(x, na.rm = TRUE)-min(x, na.rm = TRUE))

cII_df_chosen <- cII_df_chosen[rowSums(is.na(cII_df_chosen)) != ncol(cII_df_chosen), ]
cII_df_not_chosen <- cII_df_not_chosen[rowSums(is.na(cII_df_not_chosen)) != ncol(cII_df_not_chosen), ]
cII_df_7_nona_mean_df <- cII_df_7_nona_mean_df[rowSums(is.na(cII_df_7_nona_mean_df)) != ncol(cII_df_7_nona_mean_df), ]

rownames(cII_df_chosen) <- cII_df_chosen$X2
rownames(cII_df_not_chosen) <- cII_df_not_chosen$X2
rownames(cII_df_7_nona_mean_df) <- cII_df_7_nona_mean_df$X2

cII_df_7_nona_mean_df_w_nan <- cII_df_7_nona_mean_df 

keepgoing <- TRUE
if (keepgoing == TRUE){
xmax <- max(as.numeric(row.names(cII_df_7_nona_mean_df)))
xmin <- min(as.numeric(row.names(cII_df_7_nona_mean_df)))

ppi <- 300
library(ggplot2)
dir.create("/home/Figures")
pdf("/home/Figures/Mean_Immunogenicity_Score_of_Core_Proteins", width=10, height=7)
xxx <- as.numeric(row.names(cII_df_chosen))
xxy <- as.numeric(row.names(cII_df_not_chosen))

cat("*** PLOT MEAN IMMUNOGENICITY SCORE OF CORE PROTEINS ***\n")

ggplot(cII_df_7_nona_mean_df, aes(x= as.numeric(row.names(cII_df_7_nona_mean_df)), y=mean), color = ifelse(mean <= threshold_value)) + 
  geom_point(colour="#90EEAD") + 
  theme(plot.title = element_text(face = "bold", hjust = 0.5)) + 
  ggtitle("Mean Immunogenicity Score of Core Proteins") + xlab("Cluster") + ylab("Percentile Rank") + 
  theme_classic() + 
  theme(axis.text.x = element_text(color="black"), axis.text.y = element_text(color="black"), axis.line.x = element_blank(), axis.ticks.x = element_blank()) + 
  
  geom_point(data=cII_df_chosen, aes(x=as.numeric(row.names(cII_df_chosen)), y=cII_df_chosen$mean), color="black") + 
  annotate("text", x = as.numeric(row.names(cII_df_chosen)), y=cII_df_chosen$mean, label = as.numeric(row.names(cII_df_chosen)), hjust = 1, vjust = rep(c(1.5, -0.5), length.out=length(xxx)), colour = "black", size=3) + 
  annotate("text", x = as.numeric(row.names(cII_df_not_chosen)), y=cII_df_not_chosen$mean, label = as.numeric(row.names(cII_df_not_chosen)), hjust = 1, vjust = rep(c(1.5, -0.5), length.out=length(xxy)), colour = "blue", size=3) + 
  
  scale_x_continuous(breaks = divN(xmax, xmin, 5)) +
  geom_hline(yintercept=threshold_value, linetype="dashed") +
  scale_y_continuous(trans="reverse") +
  theme(axis.text.x = element_text(angle = 90))

dev.off() 


#----------

# SAVE SEQUENCES OF PROTEINS FROM THE CHOSEN CLUSTERS IN SEPARATE FILES
print(" *** SAVE SEQUENCES OF PROTEINS FROM THE CHOSEN CLUSTERS IN SEPARATE FILES *** ")
fasta_ids = read.table(fasta_id_list_file, header=FALSE, stringsAsFactors = FALSE)
cmg_ids = read.table(cmg_id_list_file, header=FALSE, stringsAsFactors = FALSE)

trans_ids <- cbind(cmg_ids, fasta_ids)
names(trans_ids) <- c("cmg_id", "fasta_id")

#print(head(trans_ids))

keepgoing<-TRUE
if (keepgoing){

sequences_path <- TMHMM_selected_protein_sequences
output_path <- '/home/chosen_clusters_protein_sequences/'
  
chosen_clusters <- surf_df[surf_df$X1 %in% cII_df_chosen$X2,]

dir.create(output_path)

total <- nrow(chosen_clusters)
pb <- progress_bar$new(total = total, format = " [:bar] :percent eta: :eta")
for(c in 1:nrow(chosen_clusters)){
  pb$tick()

  cluster <- chosen_clusters[c,1]

#  print(cluster)

  output_file <- paste(output_path, "cluster", cluster, sep='')
#  print(output_file)
  for (protein_key in chosen_clusters[c,c(-1,-2)]){
#    print(protein_key)

    if (protein_key != ""){
#      print(protein_key)
      protein_key <- trans_ids[trans_ids$cmg_id == paste(protein_key, '.consensus3', sep=""), "fasta_id"]
      protein_key_path <- paste(sequences_path, protein_key, sep='')
#      print(protein_key_path)

      sequence_file <- Sys.glob(protein_key_path)

#      print(protein_key_path)
      sequence <- scan(sequence_file, "r", quiet=TRUE)
      write(sequence,file=output_file,append=TRUE)
    } 
  }
}

}

} #remove

#---------------------
#quit()
# GET ANTIGENIC PREDICTION FILES AND SEPARATING THEM IN SPECIFIC FOLDERS
print(" *** GET ANTIGENIC PREDICTION FILES AND SEPARATING THEM IN SPECIFIC FOLDERS *** ")

log_file <- file("/home/R_output/2_meanCluster.log", open="a")
sequences_path <- IEDB_classII_predictions_folder
output_path <- '/home/classII_immuno_predictions_chosen/'
chosen_clusters <- surf_df[surf_df$X1 %in% cII_df_chosen$X2,]

tar_immuno_pred <- lapply(list.files(sequences_path), function (x) untar(paste(sequences_path, x, sep=''), list = TRUE))
unlisted_tar <- unlist(tar_immuno_pred)

gather_prediction <- function(row, unlisted_tar){
  #  print(row[1])
  cluster_number <- row[1]
  cluster_proteins <- row[c(-1,-2)]
  cluster_proteins <- cluster_proteins[cluster_proteins != ""]
  tar_paths <- lapply(cluster_proteins, function(x) unlisted_tar[grepl(x,unlisted_tar)])
  nice <- lapply(tar_paths, function(x) create_dir_and_extract(cluster_number, x))
  
  return (tar_paths)
}

create_dir_and_extract <- function(cluster_number, tar_path){
  strain_name <-  gsub('/.*','.tar.xz', tar_path)
  output_folder <- gsub(' ', '', paste(output_path, "cluster", cluster_number, sep=''))
  dir.create(output_folder)
  #  print(paste(sequences_path, strain_name, "files=", tar_path, "exdir=", output_folder, "extras=--strip-components=1", sep=' '))
  untar(paste(sequences_path, strain_name, sep=''), files=tar_path, exdir=output_folder, extras="--strip-components=1")
}

invisible(pbapply(chosen_clusters, 1, function(x) gather_prediction(x, unlisted_tar)))

# #print(chosen_clusters)
# dir.create(output_path)
# total <- nrow(chosen_clusters)
# pb <- progress_bar$new(total = total, format = " [:bar] :percent eta: :eta")
# 
# for(c in 1:nrow(chosen_clusters)){
# 
#   pb$tick()
# #  progress(c, max.value = nrow(chosen_clusters), progress.bar = TRUE)
#   
#   cluster <- chosen_clusters[c,1]
# #  cat(cluster)
# #  cat("... ")
# 
#   cat(cluster, file = log_file)
# 
#   output_folder <- paste(output_path, "cluster", cluster, sep='')
#   dir.create(output_folder)
#   #print(output_folder)
#   cat(output_folder, file = log_file)
# 
#   for (protein_key in chosen_clusters[c,c(-1,-2)]){
#     if (protein_key != ""){
#       protein_key <- trans_ids[trans_ids$cmg_id == paste(protein_key, '.consensus3', sep=""), "fasta_id"]
# 
#       cat("\n", file = log_file)
#       cat(paste("Looking for protein ", protein_key, sep=""), file = log_file)
# 
#       for (cluster in list.files(sequences_path)){
#         cat(paste("Looking into cluster ", cluster, sep=""), file = log_file)
# 
#         cluster_proteins <- untar(paste(sequences_path, cluster, sep=''), list = TRUE)
#         cat(paste(", which has ", length(cluster_proteins), " proteins.", sep=""), file = log_file)
# 
#         for (cluster_protein in cluster_proteins){
#           
#           tarxz_path <- gsub(".consensus3", "", tail(unlist(strsplit(cluster_protein, "/")), 1))
#           
#          if (protein_key == tarxz_path){
#           #cat(" ")
#           cat(paste(protein_key, " has been found.", sep=""), file = log_file)
# 
#           cluster_protein_key <- cluster_protein
# 
#           setwd(output_folder)
#           untar(paste(sequences_path, cluster, sep=''), files=cluster_protein, exdir=output_folder, extras="--strip-components=2")
# 
#           cat(paste(protein_key, " has been extracted.", sep=""), file = log_file)
# 
#           cat("\n", file = log_file)
#          }
#          if (protein_key == tarxz_path){
#           #cluster protein level
#           break         
#          }
#         }
#          if (protein_key == tarxz_path){
#           #cluster level
#           break
#          }
#       }
#     } 
#   }
# }
# 
