#!/usr/bin/Rscript

source("/scripts/epitocore_df.R")
source('/scripts/configuration_file.R')

suppressMessages(library(dplyr))
suppressMessages(library(tidyr))
suppressMessages(library(ggplot2))

wd <- main_directory
setwd(wd)

load(paste(wd, 'datastruct.RData', sep='/'))

dir.create(paste(wd, 'Tables', sep='/'))

cat("    * * * GET MINIMUM SETS * * * \n")

#----------------------------

#minimum set of peptides of a single protein that allows maximum allele coverage
set_by_protein <- df %>%
  group_by(cluster, order) %>%
  arrange(consensus_percentile_rank) %>%
  filter(outside_ratio >= 0.5) %>%
  filter(type == "EPITOPE") %>%
  distinct(allele, .keep_all = TRUE) %>%
  arrange(cluster, order)

write.table(set_by_protein[,-c(10:11)], file=paste(wd, 'Tables/Set_By_Protein.tsv', sep='/'), quote=FALSE, sep='\t', row.names=FALSE)

#number of alleles covered by a set of peptides from a single protein 
set_count_by_protein <- df %>%
  group_by(cluster, order) %>%
  arrange(consensus_percentile_rank) %>%
  filter(outside_ratio >= 0.5) %>%
  filter(type == "EPITOPE") %>%
  distinct(allele, .keep_all = TRUE) %>%
  tally(name="HLA Coverage")

write.table(set_count_by_protein, file=paste(wd, 'Tables/Max_HLA_Coverage_By_Protein.tsv', sep='/'), quote=FALSE,sep='\t', row.names=FALSE)

#----------------------------

#minimum set of peptides of a single cluster that allows maximum allele coverage
set_by_cluster <- df %>%
  group_by(cluster) %>%
  arrange(consensus_percentile_rank) %>% 
  filter(outside_ratio >= 0.5) %>%
  filter(type == "EPITOPE") %>%
  distinct(allele, .keep_all = TRUE) %>%
  arrange(cluster, order)

write.table(set_by_cluster[,-c(10:11)], file=paste(wd, 'Tables/Set_By_Cluster.tsv', sep='/'), quote=FALSE,sep='\t', row.names=FALSE)

#number of alleles covered by a set of peptides from a single cluster 
set_count_by_cluster <- df %>%
  group_by(cluster) %>%
  arrange(consensus_percentile_rank) %>%
  filter(outside_ratio >= 0.5) %>%
  filter(type == "EPITOPE") %>%
  distinct(allele, .keep_all = TRUE) %>%
  tally(name="HLA Coverage")

write.table(set_count_by_cluster, file=paste(wd, 'Tables/Max_HLA_Coverage_By_Cluster.tsv', sep='/'), quote=FALSE,sep='\t', row.names=FALSE)

#----------------------------

#minimum set of peptides of all cluster that render maximum allele coverage
#filtered by their frequencies
#ordered by higher promiscuity and lower consensus_percentile_rank

set_by_any_cluster_B <- df %>%
  dplyr::arrange(allele, desc(promiscuity), peptide, consensus_percentile_rank, order) %>% #ordenando por alelo, promiscuidade decrescente, peptídeo e escore imunogênico
  filter(outside_ratio >= 0.5) %>%  #filtrando apenas os externos
  filter(type == "EPITOPE") %>% #das linhas que tem epítopos
  filter(frequency >= minimum_strain_occurrence) %>% #e frequência maior ou igual a n
  distinct(allele, .keep_all = TRUE) %>% #somente uma linha pra cada alelo, mantendo a linha inteira
  arrange(cluster, order) #ordenando por cluster e depois por nome de proteina

write.table(set_by_any_cluster_B[,-c(10:11)], file=paste(wd, 'Tables/Set_By_Any.tsv', sep='/'), quote=FALSE,sep='\t', row.names=FALSE)
  
set_count_by_any_cluster_B <- df %>%
  dplyr::arrange(allele, order, desc(promiscuity), peptide, consensus_percentile_rank, order) %>% #ordenando por alelo, promiscuidade decrescente, peptídeo e escore imunogênico
  filter(outside_ratio >= 0.5) %>%  #filtrando apenas os externos
  filter(type == "EPITOPE") %>% #das linhas que tem epítopos
  filter(frequency >= minimum_strain_occurrence) %>% #e frequência maior ou igual a n
  distinct(allele, .keep_all = TRUE) %>% #somente uma linha pra cada alelo, mantendo a linha inteira
  arrange(cluster, order) %>% #ordenando por cluster e depois por nome de proteina
  tally(name="HLA Coverage")

write.table(set_count_by_any_cluster_B, file=paste(wd, 'Tables/Max_HLA_Coverage_By_Any.tsv', sep='/'), quote=FALSE,sep='\t', row.names=FALSE)

  
#---------------

#plot minimum set

cat("    * * * PLOT MINIMUM SET * * * \n")

#plot minimum set B

orders <- unique(set_by_any_cluster_B$order)

df_set_by_any_cluster_B <- df %>%
  dplyr::arrange(allele, consensus_percentile_rank) %>%
  filter(type != "EPITOPE") %>%
  filter(order %in% orders) %>%
  #distinct(allele, .keep_all = TRUE) %>%
  arrange(cluster, order)

df_set_by_any_cluster_B <- rbind(df_set_by_any_cluster_B, set_by_any_cluster_B)

df_set_by_any_cluster_B <- 
  df_set_by_any_cluster_B %>%
  dplyr::arrange(cluster, order, desc(type))

pdf(paste(wd, "Figures/Minimum_Set_After_Filtering_By_Outside_Ratio.pdf", sep='/'), width=10, height=6)
print(plot_minimum_set(df_set_by_any_cluster_B))
dev.off()

#----------------

#table counts peptides inside and outside

protein_count <- df %>% group_by(cluster) %>% distinct(order) %>% tally(name="Protein Count")
write.table(protein_count, file=paste(wd, 'Tables/Number_of_Proteins_Per_Cluster_(w_Ratio_Filtering).tsv', sep='/'), quote=FALSE,sep='\t', row.names=FALSE)

outside_epitope_count <- df %>% group_by(cluster) %>% filter(outside_ratio > 0.5) %>% distinct(peptide) %>% tally(name="Epitope Count")
write.table(outside_epitope_count, file=paste(wd, 'Tables/Number_of_Epitopes_Per_Cluster_After_Outside_Ratio_Filtering.tsv', sep='/'), quote=FALSE,sep='\t', row.names=FALSE)

save(df, file = paste(wd, "df_final.RData", sep="/") )
