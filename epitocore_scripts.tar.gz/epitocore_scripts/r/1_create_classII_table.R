#!/usr/bin/Rscript
options(warn = -1)
suppressMessages(library(progress))
source('/scripts/configuration_file.R')

wd <- main_directory
surf_output <- last_surfaceome_group_file
classIIPath <- IEDB_classII_predictions_folder

nf <- max(count.fields(surf_output))
surf_df <- read.table(surf_output, sep='\t', header=FALSE, fill = NA, col.names = 1:nf, stringsAsFactors = FALSE)

surf_copy <- surf_df[,c(-1, -2)]
surf_list <- unique(unlist(as.list(surf_copy)))

fasta_ids = read.table(fasta_id_list_file, header=FALSE, stringsAsFactors = FALSE)
cmg_ids = read.table(cmg_id_list_file, header=FALSE, stringsAsFactors = FALSE)

trans_ids <- cbind(cmg_ids, fasta_ids)
names(trans_ids) <- c("cmg_id", "fasta_id")


for (tarxz in list.files(classIIPath, pattern="*xz")){
#  pb$tick()

  setwd(classIIPath)
  print(tarxz)
  untar(tarxz, exdir=classIIPath, extras="--strip-components=1")
  setwd(classIIPath)
  
  folder <- gsub('.tar.xz', '', tarxz)

#  print('-folder:-')
  total <- length(list.files(folder))
  pb <- progress_bar$new(total = total, format = " [:bar] :percent eta: :eta")

  for (file in list.files(folder)){
    pb$tick()
    skip_to_next <- FALSE
#    cat(paste("file: ", file, "\n", sep=""))

    for (protein in surf_list){

      if (protein != ""){
      protein_id <- trans_ids[trans_ids$cmg_id == paste(protein, ".consensus3", sep=""), "fasta_id"]

      if (protein_id == gsub(".consensus3", "", file)){
#        cat(file)
#        cat('... ')

        df_file = paste(folder, file, sep='/')

#        print('-dataframe file:-')
#        cat(df_file)
#        cat('...')

        tryCatch(dfA <- read.table(df_file, sep='\t', header=TRUE, stringsAsFactors = FALSE)[c('allele', 'peptide', 'consensus_percentile_rank', 'start', 'end')], error = function(e) {skip_to_next <- TRUE})
        if(skip_to_next) {next}

#        dfA = dfA[dfA[, "consensus_percentile_rank"] <= 0.05,]
        dfA = dfA[dfA[, "consensus_percentile_rank"] <= consensus_percentile_rank_filter1,]
        
        surf_copy[surf_copy==protein] <- mean(dfA$consensus_percentile_rank)

        if (any(surf_copy==protein) == TRUE){
 #         print(protein)
 #         print(mean(dfA$consensus_percentile_rank))
        }
      }
    }
  }
}

#  print('deleting extracted file......')
  unlink(folder, recursive=TRUE)
#  cat('\n')
#  cat('\n')
#  cat('\n')
}

surf_copy <- cbind(surf_df[c(1,2)], surf_copy)

dir.create("/home/R_output")
write.table(surf_df, file = "/home/R_output/coreSurfaceome_df.tsv", sep="\t")
write.table(surf_copy, file = "/home/R_output/classII_df.tsv", sep="\t")
