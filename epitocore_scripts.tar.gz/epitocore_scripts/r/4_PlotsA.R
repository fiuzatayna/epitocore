#!/usr/bin/Rscript

options( warn = -1 )

source('/scripts/epitocore_df.R')
source('/scripts/configuration_file.R')

suppressMessages(library(dplyr))
suppressMessages(library(tidyr))
suppressMessages(library(ggplot2))

wd <- main_directory
setwd(wd)

load(paste(wd, 'datastruct.RData', sep='/'))
dir.create("/home/Figures")

#FREQUENCY
cat("    * * * DO FREQUENCY PLOT * * * \n")
frequency = aggregate(df$order, list(cluster=df$cluster, peptide=df$peptide),  frequency<- function(x) length(unique(x)))

pdf(paste(wd, 'Figures/Peptide_Conservation_By_Cluster.pdf', sep='/'), width=12, height=6)

ggplot(frequency, aes(x=as.factor(frequency$cluster), fill=as.factor(frequency$x))) + 
  geom_bar(position = position_stack(reverse = TRUE)) +  
  theme(plot.title = element_text(face = "bold", hjust = 0.5)) + 
#  ggtitle("Conservação dos Peptídeos Clusters") + xlab("Clusters") + ylab("Número de Peptídeos") + 
#  labs(fill = "Conservação") + theme_classic() + 
  ggtitle("Peptide Conservation By Cluster") + xlab("Clusters") + ylab("Number of Peptides") + 
  labs(fill = "Conservation") + theme_classic() + 
    
  theme(axis.text.x = element_text(color="black", angle = 90, vjust=+0.5, hjust=+0.4), axis.text.y = element_text(color="black"), axis.line.x = element_blank(), axis.ticks.x = element_blank())  + 
  scale_y_continuous(expand = c(0,0)) + 
  scale_fill_manual(values=fza_colors(max(frequency$x)))

dev.off()

#PROMISCUITY
cat("    * * * DO PROMISCUITY PLOT * * * \n")
promiscuity = aggregate(df$allele, list(cluster=df$cluster, peptide=df$peptide),  function(x) length(unique(x)))


pdf(paste(wd, 'Figures/Peptide-MHC_Promiscuity_in_Clusters.pdf', sep='/'), width=12, height=6)

ggplot(promiscuity, aes(x=as.factor(promiscuity$cluster), fill=as.factor(promiscuity$x))) + 
  geom_bar(position = position_stack(reverse = TRUE))   +  
  theme(plot.title = element_text(face = "bold", hjust = 0.5)) + 
  
  # ggtitle("Promiscuidade Peptídeo-MHC nos Clusters") + xlab("Clusters") + ylab("Número de peptídeos") + 
  # labs(fill = "Promiscuidade Peptídeo-MHC") + theme_classic() + 
  ggtitle("Peptide-MHC Promiscuity in Clusters") + xlab("Clusters") + ylab("Number of peptides") + 
  labs(fill = "Peptide-MHC Promiscuity") + theme_classic() + 
    
  theme(axis.text.x = element_text(color="black", angle = 90, vjust=+0.5, hjust=+0.4), axis.text.y = element_text(color="black"), axis.line.x = element_blank(), axis.ticks.x = element_blank())  + 
  scale_y_continuous(expand = c(0,0)) + 
  scale_fill_manual(values=sva_colors(max(promiscuity$x)))

dev.off()


#CROSS
cat("    * * * DO CROSS FREQUENCY VERSUS PROMISCUITY PLOT * * * \n")
fVSp = merge(frequency, promiscuity, by="peptide")
fVSp = aggregate(fVSp$cluster.x, list(frequency=fVSp$x.x, promiscuity=fVSp$x.y, cluster=fVSp$cluster.x), length)

pdf(paste(wd, 'Figures/Candidate_Peptide_Promiscuity_vs._Frequency.pdf', sep='/'), width=12, height=8)

ggplot(fVSp, aes(x=fVSp$frequency, y=fVSp$promiscuity, color=as.factor(fVSp$cluster), size=fVSp$x, stroke = 0, label=as.factor(fVSp$cluster))) + 
  scale_size(breaks = c(1,10,30)) + geom_jitter(alpha=0.6, position = position_jitter(seed = 1)) + 
  #geom_text(aes(label=fVSp$cluster),position = position_jitter(seed = 1), size=3, color="black") + 
  scale_x_continuous(breaks = round(seq(min(fVSp$frequency), max(fVSp$frequency), by = 1),1)) + 
  scale_y_continuous(breaks = round(seq(min(fVSp$promiscuity), max(fVSp$promiscuity)+1, by = 1),1)) + 
  guides(fill = guide_legend(override.aes = list(size = 20))) +
  labs(color = "Cluster", size= "Count") +
  ggtitle("Candidate Peptide Promiscuity vs. Frequency") + xlab("Frequency") + ylab("Promiscuity") + 
  theme_classic() + 
  #theme(axis.text.x = element_text(color="black", angle = 0), axis.text.y = element_text(color="black"), axis.line.x = element_blank(), axis.ticks.x = element_blank(), legend.position = "none")
  #theme(axis.text.x = element_text(color="black", angle = 0), axis.text.y = element_text(color="black"), axis.line.x = element_blank(), axis.ticks.x = element_blank())
  theme(axis.text.x = element_text(color="black", angle = 0), axis.text.y = element_text(color="black"))

dev.off()

#PLOT ALL CLUSTERS

cat("    * * * PLOT ALL CLUSTERS * * * \n")

#plot all clusters

pdf(paste(wd, 'Figures/Epitope_and_Transmembrane_Topology_of_Clusters.pdf', sep='/'), width=15, height=10)

for (cluster in sort(unique(df$cluster))){
  temp_df <- df[df$cluster == cluster, ]
  print(plot_like_uniplot(temp_df))
}

dev.off() 
