#!/usr/bin/Rscript

#epitocore dataframe functions

get_outside_ratio_B <- function(df){
  
  df$outside_ratio <- NA
  n = 0
  v = 0
  total = length(unique(df$order))
  porcento = total*0.01
  
  for (protein in unique(df$order)){
    
    if(n - porcento > 0){
      n <- 0
    }
    
    outside <- df %>%
      filter(type == 'OUTSIDE') %>%
      filter(order == protein) %>%
      select(start,end,order)
    
    
    for (row in 1:nrow(df)) {
      if ((df[row, "order"] == protein) & (df[row, "type"]  == 'EPITOPE')){
        start <- df[row, "start"]
        end  <- df[row, "end"]     
        
        if (dim(outside) == 1){
          df[row, "outside_ratio"] <- (max(length(apply(outside[c(1,2)], 1, function(x) intersection(x,start,end))))/(end-start+1))
        }
        else {
          df[row, "outside_ratio"] <- (max(lengths(apply(outside[c(1,2)], 1, function(x) intersection(x,start,end))))/(end-start+1))
        }
        df$outside_ratio[which(df$outside_ratio == -Inf)] = 0
      }
    }
    n = n + 1
    v = v + 1
  }  
#  cat("100%")
  return(df)
}

intersection <- function(x,e1,e2){
  return (intersect(x[1]:x[2],e1:e2))
}

strsplit <- function(x, split, type = "remove", perl = FALSE, ...) {
  #CODE BY JAKOB GEPP https://www.r-bloggers.com/strsplit-but-keeping-the-delimiter/
  if (type == "remove") {
    # use base::strsplit
    out <- base::strsplit(x = x, split = split, perl = perl, ...)
  } else if (type == "before") {
    # split before the delimiter and keep it
    out <- base::strsplit(x = x,
                          split = paste0("(?<=.)(?=", split, ")"),
                          perl = TRUE,
                          ...)
  } else if (type == "after") {
    # split after the delimiter and keep it
    out <- base::strsplit(x = x,
                          split = paste0("(?<=", split, ")"),
                          perl = TRUE,
                          ...)
  } else {
    # wrong type input
    stop("type must be remove, after or before!")
  }
  return(out)
}

add_protein_rows<-function(df, protein, cluster){
  length <- as.numeric(gsub("len=", "", get_length(tmhmmPath,gsub(".consensus3","",protein))))
  temp_df <- data.frame("allele"=NA,"peptide"=NA,"consensus_percentile_rank"=NA,"start"=1,"end"=length,"cluster"=cluster,"type"="PROTEIN", "description"=protein, "order"=protein, "occurrences"=NA, "mean_scoring"=NA)
  df <- rbind(temp_df, df)
  return(df)
}

add_tmtopology_rows<-function(df, protein, cluster){
  library(stringr)
  
  length <- as.numeric(gsub("len=", "", get_length(tmhmmPath,gsub(".consensus3","",protein))))
  topology <- gsub('Topology=', '', get_topology(tmhmmPath,gsub(".consensus3","",protein)))
  
  topology_split = unlist(strsplit(topology, '-'))
  
  for (topo in topology_split){
    topo <- as.character(topo)
    #beginning of topology
    if (grepl('^[[:alpha:]]', topo) == TRUE){
      end <- as.numeric(unlist(strsplit(topo, '[[:alpha:]]', type='after'))[2])
      symbol <- unlist(strsplit(topo, '[[:alpha:]]', type='after'))[1]
      
      if (symbol == 'i') type='INSIDE' else type='OUTSIDE'
      if (is.na(end)) end=length
      
      temp_df <- data.frame("allele"=NA,"peptide"=NA,"consensus_percentile_rank"=NA,"start"=1,"end"=end-1,"cluster"=cluster,"type"=type, "description"=topology, "order"=protein, "occurrences"=NA, "mean_scoring"=NA)
      df <- rbind(temp_df, df)
      
    }
    else if (grepl('^[[:digit:]]', topo) == TRUE && grepl('[[:digit:]]$', topo) == TRUE){
      #transmembrane section
      start <- as.numeric(unlist(strsplit(topo, '[[:alpha:]]'))[1])
      previous <- end
      
      temp_df <- data.frame("allele"=NA,"peptide"=NA,"consensus_percentile_rank"=NA,"start"=previous,"end"=start,"cluster"=cluster,"type"="TRANSMEMBRANE", "description"=topology, "order"=protein, "occurrences"=NA, "mean_scoring"=NA)
      df <- rbind(temp_df, df)
      
      #inner or outer section
      end <- as.numeric(unlist(strsplit(topo, '[[:alpha:]]'))[2])
      symbol <- gsub('[[:digit:]]', '', topo)
      
      #temp_string <- strrep(symbol,end-start+1)
      #transmembrane_string <- paste(transmembrane_string, temp_string, sep='')
      
      if (symbol == 'i') type='INSIDE' else type='OUTSIDE'
      #if (is.na(end)) end=length
      
      temp_df <- data.frame("allele"=NA,"peptide"=NA,"consensus_percentile_rank"=NA,"start"=start+1,"end"=end-1,"cluster"=cluster,"type"=type, "description"=topology, "order"=protein, "occurrences"=NA, "mean_scoring"=NA)
      df <- rbind(temp_df, df)
      
    }
    else if (grepl('[[:alpha:]]$', topo) == TRUE){
      #transmembrane section
      start <- as.numeric(unlist(strsplit(topo, '[[:alpha:]]'))[1])
      previous <- end
      temp_df <- data.frame("allele"=NA,"peptide"=NA,"consensus_percentile_rank"=NA,"start"=previous,"end"=start,"cluster"=cluster,"type"="TRANSMEMBRANE", "description"=topology, "order"=protein, "occurrences"=NA, "mean_scoring"=NA)
      df <- rbind(temp_df, df)
      
      symbol <- unlist(strsplit(topo, '[[:alpha:]]', type='before'))[2]
      
      if (symbol == 'i') type='INSIDE' else type='OUTSIDE'
      if (is.na(end)) end=length
      
      temp_df <- data.frame("allele"=NA,"peptide"=NA,"consensus_percentile_rank"=NA,"start"=start+1,"end"=length,"cluster"=cluster,"type"=type, "description"=topology, "order"=protein, "occurrences"=NA, "mean_scoring"=NA)
      df <- rbind(temp_df, df)
    }
  }
  return(df)
}

add_epitopelist_rows<- function(df, protein, cluster){
  
  start = df[df$type == "PROTEIN",]$start
  end = df[df$type == "PROTEIN",]$end
  
  start_ep = df[df$type == "EPITOPE",]$start
  end_ep = df[df$type == "EPITOPE",]$end
  score_ep = df[df$type == "EPITOPE",]$consensus_percentile_rank
  
  if ((length(start_ep) == length(end_ep)) && (length(end_ep) == length(score_ep))){
    
    positions <- seq(start, end)
    occurrences <- rep(0, end)
    mean_scoring <- rep(0, end)
    
    for (i in 1:length(start_ep)){
      occurrences[start_ep[i]:end_ep[i]] <- occurrences[start_ep[i]:end_ep[i]] + 1
    }
    
    
    for (i in 1:length(start_ep)){
      mean_scoring[start_ep[i]:end_ep[i]] <- mean_scoring[start_ep[i]:end_ep[i]] + score_ep[i]
    }
    
    mean_scoring <- mean_scoring/occurrences
  }
  
  temp_df <- data.frame("allele"=NA,"peptide"=NA,"consensus_percentile_rank"=NA,"start"=start,"end"=end,"cluster"=cluster,"type"="OVERLAP", "description"=protein, "order"=protein)
  temp_df$occurrences <- list(occurrences) 
  temp_df$mean_scoring <- list(mean_scoring)
  df <- rbind(temp_df, df)
  
  return(df)
}

get_length <- function(path, query){
  for (pred in list.files(path)){
    temp_file = paste(path, pred, sep="")
    temp = read.table(temp_file, sep='\t', stringsAsFactors = FALSE)
    if (length(temp$V2[temp$V1 == query]) >= 1){
      return(temp$V2[temp$V1 == query]) 
    }
  }
}

get_topology <- function(path, query){
  for (pred in list.files(path)){
    temp_file = paste(path, pred, sep="")
    temp = read.table(temp_file, sep='\t', stringsAsFactors = FALSE)
    if (length(temp$V6[temp$V1 == query]) >= 1){
      return(temp$V6[temp$V1 == query]) 
    }
  }
}

#FUNCTIONS

fza_colors <- function(n) {
  start <- 105
  end <- 425
  hues = seq(start, end, length = n + 1)
  hcl(h = hues, c = c(100,75), l = c(60,70))[1:n]
}

sva_colors <- function(n) {
  start <- 55
  end <- 475
  hues = seq(start, end, length = n + 1)
  hcl(h = hues, c = c(50,75), l = c(80,70))[1:n]
}

tna_colors <- function(n) {
  start <- 3
  end <- 363
  hues = seq(start, end, length = n + 1)
  hcl(h = hues, c = c(100,90), l = c(54,60))[1:n]
}

plot_like_uniplot<-function(temp_df){
  
  #based on http://rforbiochemists.blogspot.com/2017/08/drawing-nfkappab-protein-schematics.html
  
  temp_df['new_order'] <- as.numeric(as.factor(as.numeric(as.factor(temp_df$order))))
  #set up the canvas in ggplot (no data added)
  plot_start <- -max(temp_df$end)*0.01
  plot_end <- max(temp_df$end) + max(temp_df$end)*0.1

  cat(paste("Cluster ", temp_df$cluster[1], " | ", sep=""))
#  print(temp_df$cluster[1])

  #ENGLISH
  p <- ggplot() +
    scale_x_continuous(name="Amino acid position", limits=c(plot_start, plot_end), breaks=divN(0,max(temp_df$end),15)) +
    scale_y_continuous(name="Protein", limits=c(0.5, max(temp_df$new_order)+0.5), breaks=seq(1,max(temp_df$new_order),1)) +
    ggtitle(paste("Epitope and Transmembrane Topology of Cluster", temp_df$cluster[1], "Proteins")) +
    theme_classic() +
    theme(axis.text.x = element_text(color="black", angle=90), axis.text.y = element_text(color="black"), axis.line.y = element_blank(), axis.line.x = element_blank(), axis.ticks.x = element_blank())
  p # show the object
  
  # #PORTUGUES
  # p <- ggplot() +
  #   scale_x_continuous(name="Posição do aminoácido", limits=c(plot_start, plot_end), breaks=divN(0,max(temp_df$end),15)) +
  #   scale_y_continuous(name="Proteina", limits=c(0.5, max(temp_df$new_order)+0.5), breaks=seq(1,max(temp_df$new_order),1)) +
  #   ggtitle(paste("Topologia Imunogênica e Trans-membranar das Proteínas do Cluster", temp_df$cluster[1])) +
  #   labs(fill = "Representação") + 
  #   theme_classic() +
  #   theme(text = element_text(size=15), axis.text.x = element_text(color="black", angle=90), axis.text.y = element_text(color="black"), axis.line.y = element_blank(), axis.line.x = element_blank(), axis.ticks.x = element_blank())
  # p # show the object
  
  #draw protein length
  p <- p + geom_rect(data= temp_df[temp_df$type == "PROTEIN",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order+0.2),
                     fill = "grey")
  p
  
  #annotate with fastaid
  p <- p + annotate("text", 
                    x = temp_df[temp_df$type == "PROTEIN",]$start,
                    y = temp_df[temp_df$type == "PROTEIN",]$new_order - 0.3, 
                    #label = gsub(".consensus3", "", temp_df[temp_df$type == "PROTEIN",]$description),
                    label = gsub(".consensus3", "", temp_df[temp_df$type == "PROTEIN",]$fasta_id),
                    hjust = 0,
                    size = 5)
  p
  
  #plot epitope fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "EPITOPE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order,
                                 ymax=new_order+0.2,
                                 fill = type
                     )) + 
  #scale_fill_manual(labels = c("Epítopo", "Intracelular", "Extracelular", "Trans-membranar"), values=tna_colors(max(4)))
  scale_fill_manual(labels = c("Epitope", "Intracellular", "Extracellular", "Transmembrane"), values=tna_colors(max(4)))
  p
  
  
  #plot outside location fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "OUTSIDE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order,
                                 fill = type
                     ))
  p
  
  #plot inside location fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "INSIDE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order,
                                 fill = type
                     ))
  
  p
  
  #plot transmembrane location fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "TRANSMEMBRANE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order,
                                 fill = type
                     ))
  p
  
  return(p)
}

divN<- function(start, end, N){
  divN <- c()
  values = seq(start, end)
  for (number in values){
    if (number %% N == 0) divN <- c(divN, number) 
  }
  return(divN)
}


plot_minimum_set<-function(temp_df){
  
  #based on http://rforbiochemists.blogspot.com/2017/08/drawing-nfkappab-protein-schematics.html
#  temp_df['new_order'] <- as.numeric(as.factor(as.numeric(as.factor(temp_df$cluster))))
  #set up the canvas in ggplot (no data added)
  clusters <- temp_df %>% distinct(order, .keep_all = TRUE) %>% pull(cluster)
  temp_df['new_order'] <- as.numeric(as.factor(as.numeric(as.factor(temp_df$order))))

  plot_start <- -max(temp_df$end)*0.01
  plot_end <- max(temp_df$end) + max(temp_df$end)*0.1

  #ENGLISH
  p <- ggplot() +
    scale_x_continuous(name="Amino acid position", limits=c(plot_start, plot_end), breaks=divN(0,max(temp_df$end),15)) +
    scale_y_continuous(name="Protein", limits=c(0.5, max(temp_df$new_order)+0.5), breaks=seq(1,max(temp_df$new_order),1), labels=clusters) +
    ggtitle(paste("Immunogenic and Transmembrane Topology of Proteins from the Minimum Set")) +
    labs(fill = "Key") +
    theme_classic() +
    theme(text = element_text(size=15), 
          axis.text.x = element_text(color="black", angle=90), 
          axis.text.y = element_text(color="black"), 
          axis.line.y = element_blank(), 
          axis.line.x = element_blank(), 
          axis.ticks.x = element_blank())
  p # show the object

  #PORTUGUÊS
  # p <- ggplot() +
  #   scale_x_continuous(name="Posição dos Aminoácidos", limits=c(plot_start, plot_end), breaks=divN(0,max(temp_df$end),15)) +
  #   scale_y_continuous(name="Proteína", limits=c(0.5, max(temp_df$new_order)+0.5), breaks=seq(1,max(temp_df$new_order),1)) +
  #   ggtitle(paste("Topologia Imunogênica e Trans-membranar das Proteínas do Conjunto Mínimo")) +
  #   labs(fill = "Representação") +
  #   theme_classic() +
  #   theme(text = element_text(size=15), 
  #         axis.text.x = element_text(color="black", angle=90), 
  #         axis.text.y = element_text(color="black"), 
  #         axis.line.y = element_blank(), 
  #         axis.line.x = element_blank(), 
  #         axis.ticks.x = element_blank())
  # p # show the object
  
  #draw protein length
  p <- p + geom_rect(data= temp_df[temp_df$type == "PROTEIN",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order+0.2),
                     fill = "grey")
  p
  
  #annotate with fastaid
  p <- p + annotate("text", 
                    x = temp_df[temp_df$type == "PROTEIN",]$start,
                    y = temp_df[temp_df$type == "PROTEIN",]$new_order - 0.4, 
                    #label = paste(temp_df[temp_df$type == "PROTEIN",]$cluster, gsub(".consensus3", "", temp_df[temp_df$type == "PROTEIN",]$description), sep=" "),
                    label = paste(temp_df[temp_df$type == "PROTEIN",]$cluster, gsub(".consensus3", "", temp_df[temp_df$type == "PROTEIN",]$fasta_id), sep=" "),
                    hjust = 0,
                    size = 5)
  p
  
  #plot epitope fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "EPITOPE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order,
                                 ymax=new_order+0.2,
                                 fill = type
                     )
  ) + 
  #scale_fill_manual(labels = c("Epítopo", "Intracelular", "Extracelular", "Trans-membranar"), values=tna_colors(max(4)))
  scale_fill_manual(labels = c("Epitope", "Intracellular", "Extracellular", "Transmembrane"), values=tna_colors(max(4)))
  p
  
  #plot outside fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "OUTSIDE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order,
                                 fill = type
                     ))
  p
  
  #plot inside fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "INSIDE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order,
                                 fill = type
                     ))
  
  p
  
  #plot transmembrane fill by type
  p <- p + geom_rect(data= temp_df[temp_df$type == "TRANSMEMBRANE",],
                     mapping=aes(xmin=start,
                                 xmax=end,
                                 ymin=new_order-0.2,
                                 ymax=new_order,
                                 fill = type
                     ))
  p
  
  return(p)
}

dir.copy <- function(from, to){

  ## check if from and to directories are valid
  if (!dir.exists(from)){
    cat('from: No such Directory\n')
    return (FALSE)
  }
  else if (!dir.exists(to)){
    cat('to: No such Directory\n')
    return (FALSE)
  }

  ## extract the directory name from 'from'
  split_ans <- unlist(strsplit(from,'/'))

  dir_name <- split_ans[length(split_ans)]

  new_to <- paste(to,dir_name,sep='/')

  ## create the directory in 'to'
  dir.create(new_to)

  ## copy all files in 'to'
  file_inside <- list.files(from,full.names = T)

  file.copy(from = file_inside,to=new_to)

  ## copy all subdirectories
  dir_inside <- list.dirs(path=from,recursive = F)

  if (length(dir_inside) > 0){
    for (dir_name in dir_inside)
      dir.copy(dir_name,new_to)
  }

  return (TRUE)
}

divN<- function(start, end, N){
  divN <- c()
  values = seq(start, end)
  for (number in values){
    if (number %% N == 0) divN <- c(divN, number) 
  }
  return(divN)
}


dir.copy <- function(from, to){

  ## check if from and to directories are valid
  if (!dir.exists(from)){
    cat('from: No such Directory\n')
    return (FALSE)
  }
  else if (!dir.exists(to)){
    cat('to: No such Directory\n')
    return (FALSE)
  }

  ## extract the directory name from 'from'
  split_ans <- unlist(strsplit(from,'/'))

  dir_name <- split_ans[length(split_ans)]

  new_to <- paste(to,dir_name,sep='/')

  ## create the directory in 'to'
  dir.create(new_to)

  ## copy all files in 'to'
  file_inside <- list.files(from,full.names = T)

  file.copy(from = file_inside,to=new_to)

  ## copy all subdirectories
  dir_inside <- list.dirs(path=from,recursive = F)

  if (length(dir_inside) > 0){
    for (dir_name in dir_inside)
      dir.copy(dir_name,new_to)
  }

  return (TRUE)
}

