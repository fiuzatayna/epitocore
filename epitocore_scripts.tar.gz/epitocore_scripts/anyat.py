#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 09:25:12 2019
@author: fiuzat
"""

#from settings import PROJECT_ROOT
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from zipfile import ZipFile
import wget
import os
import gzip
import shutil
import progressbar 


#global create_dir        
def create_dir(directory):
    import os, errno

    try:
        os.makedirs(directory)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise           
            
def get_paths( species_file, assembly_summary ):
    import re
    import pandas as pd
    
    with open ( species_file, 'r') as speciesfile:
        species_list = []
        for line in speciesfile:
            species_list.append(line.strip())

    for species in species_list:
        print("Getting paths of proteins from "+species+" to download.")
        print("")

    
    with open ( assembly_summary, 'r') as genbankfile:
        valid_entries = []
        for line in genbankfile:
            re.findall(r'|'.join(species_list), line, re.IGNORECASE)
            if any(re.findall(r'|'.join(species_list), line, re.IGNORECASE)):
                valid_e = line.split('\t')[7], line.split('\t')[8], line.split('\t')[11], line.split('\t')[19]
                valid_entries.append(valid_e)

    valid_entries = pd.DataFrame(valid_entries)
    valid_entries.drop_duplicates
    #print(valid_entries)
    return valid_entries
            
def download_ftp( species, path, extension, dir_path ):
    create_dir(dir_path)
    output_file = species.replace(' ', '_')+'_'+path.split('/')[-1]+extension
    file_path = os.path.join(dir_path, output_file)

    url = path+'/'+path.split('/')[-1]+extension

    if not os.path.isfile(file_path):
        try:
            print("Trying to download "+url)
            print("")
            wget.download(url, out=file_path)
            print("")
            print("Downloaded")
            print("")
        except:
            print("")
            print("Unexpected error with download "+url)
            print("")

def decompress ( file_ ):
    print('Decompressing '+file_)
    print("")
    with gzip.open(file_, 'rb') as f_in:
        with open(file_.replace('.gz', ''), 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

def execute_tmhmm( file, output_path ):
    import subprocess
    pbar = progressbar.ProgressBar()
    p_list = []

    outpt = '.'.join(file.split("/")[-1].split('.')[:-1])

    print(outpt)
    with open(os.path.join(output_path, outpt),"w") as out:    
#        p = subprocess.Popen(["perl", "tmhmm-2.0c/bin/tmhmm", "-short", file], stdout=out, stderr=out)
        p = subprocess.Popen(["perl", "/tmhmm-2.0c/bin/tmhmm", "-short", file], stdout=out, stderr=out)
        p_list.append(p)

#        p = subprocess.Popen(["tmhmm", "-short", file], stdout=out, stderr=out)
    
    result = []
    
    while p.stdout is not None:

        # Update spinner on one step:
        # It will update only when any line was printed to stdout!
        pbar.update()
        # Read each line:

        line = p.stdout.readline()
        # Add line in list and remove carriage return

        result.append(line.decode('UTF-8').rstrip('\r'))

        # When no lines appears:
        if not line:
            print("\n")
            p.stdout.flush()
            break

    # Show finish message, it also useful because bar cannot start new line on console, why?
    print("Finished.")
    # Results as string:
    print(''.join(result))
    for pr in p_list:
        pr.wait()
    
def remove_duplicates(infile):
    s = set()
    for line in open(infile):
        s.add(line)
    open(infile, 'w').writelines(s)

def linearize_fasta(infile):
    l = []
    print(infile)
    with open (infile, 'r') as in_file:
        for line in in_file:
            if line.startswith('>'):
                l.append(line.replace('>', '\n>'))
            if not line.startswith('>'):
                l.append(line.strip())
    
    with open (infile, 'w') as out_file:
        for item in l:
            out_file.write(item)
            
def strainZip2immuneDict(strain_zip):
    zip_file = ZipFile(strain_zip)
    lagging_string = strain_zip.split("/")[-1].replace(".zip", "")+"/"
    file_suffix = ".consensus3"
    immuneDict = {text_file.filename.replace(lagging_string,"").replace(file_suffix, "").replace("./",""): pd.read_csv(zip_file.open(text_file.filename), delimiter='\t', skiprows=[0], header=None, low_memory=False, usecols=[5,7]) for text_file in zip_file.infolist() if text_file.filename.endswith('.consensus3')}
    return immuneDict
        
def immunogenicity_by_cluster(dfA, dfB):
    plt.style.use('seaborn-pastel')

    #Set figure and size
    fig, ax = plt.subplots()
    fig.set_size_inches(25, 5)

    #ax1 = fig.add_subplot(121)

    # Hide the right and top spines
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['bottom'].set_visible(True)
    # Only show ticks on the left spine
    ax.yaxis.set_ticks_position('left')

    ax.tick_params(labelsize=15)

    y = dfA.loc[:,'2':].mean(axis=1)
    yerr = dfA.loc[:,'2':].var(axis=1)
    xy = dfA.loc[:,'0']

    z = dfB.loc[:,'2':].mean(axis=1)
    zerr = dfB.loc[:,'2':].var(axis=1)
    xz = dfB.loc[:,'0']
    
    plt.title('Mean Immunogenicity Score of Core Proteins', fontsize=15)
    plt.ylabel('Score', fontsize=15)
    plt.xlabel('Cluster', fontsize=15)
    #plt.xlim(-1,450)

    plt.scatter(xy,y, label="MHC I Scores")
    #plt.bar(xy,y, yerr=yerr, color=(0.2, 0.4, 0.6, 0))
    plt.scatter(xy[y>np.percentile(dfA.loc[:,'2':], 95)], y[y>np.percentile(dfA.loc[:,'2':], 95)],marker="x",color="black", label="Top 5% Score")
    
    plt.scatter(xz,z, label="MHC II Scores")
    #plt.bar(xz,z, yerr=zerr, color=(0.2, 0.4, 0.6, 0))
    plt.legend(loc='lower right', shadow=False)
    plt.scatter(xz[z>np.percentile(dfB.loc[:,'2':], 95)], z[z>np.percentile(dfB.loc[:,'2':], 95)],marker="x",color="black")

    
    for a,b in zip(xy[y>np.percentile(dfA.loc[:,'2':], 95)], y[y>np.percentile(dfA.loc[:,'2':], 95)]): 
        plt.text(a, b, str(a))
        
    for a,b in zip(xz[z>np.percentile(dfB.loc[:,'2':], 95)], z[z>np.percentile(dfB.loc[:,'2':], 95)]): 
        plt.text(a, b, str(a))
    
    #plt.hlines(y, xmin, xmax, colors='k', linestyles='solid', label='', *, data=None, **kwargs)
    plt.show()
    
