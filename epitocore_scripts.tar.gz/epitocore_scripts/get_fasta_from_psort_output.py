#usage python3 get_fasta_from_psort_output.py psort_output_file fasta_file output_file
#example python3 get_fasta_from_psort_output.py bacteriaA.psort bacteriaA.faa bacteriaA_filtered.faa

from Bio import SeqIO
import sys, re
import pandas as pd

psort_file = pd.read_csv(sys.argv[1], sep='\t', index_col=False)
wanted = psort_file.SeqID.values.tolist()

fasta_sequences = SeqIO.parse(sys.argv[2], 'fasta')

with open(sys.argv[3], "w") as f:
    for seq in fasta_sequences:
        if any([s for s in wanted if seq.id in s]):
            SeqIO.write([seq], f, "fasta")